############################################################################################
#
# Function for accordion
#
# Stress in Action 2025
#
#############################################################################################

accordionI <- function(tit, stat, col, text){

  accordionItem(
    title = tit,
    status = stat,
    collapsed = col,
    text
  )

}
